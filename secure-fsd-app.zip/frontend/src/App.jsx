import { useState } from "react";

const API = "http://localhost:5000/api";

export default function App() {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [message, setMessage] = useState("");

  function update(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function submit(e) {
    e.preventDefault();
    setMessage("");

    const endpoint = mode === "login" ? "/auth/login" : "/auth/register";

    try {
      const response = await fetch(API + endpoint, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      const data = await response.json();
      setMessage(data.message || "Request completed");
    } catch {
      setMessage("Unable to connect to backend");
    }
  }

  async function profile() {
    const response = await fetch(API + "/users/me", {
      credentials: "include"
    });
    const data = await response.json();
    setMessage(JSON.stringify(data, null, 2));
  }

  async function logout() {
    await fetch(API + "/auth/logout", {
      method: "POST",
      credentials: "include"
    });
    setMessage("Logged out");
  }

  return (
    <main className="container">
      <h1>Secure FSD Application</h1>
      <p>Layered security demonstration</p>

      <form onSubmit={submit}>
        {mode === "register" && (
          <input
            name="name"
            placeholder="Name"
            value={form.name}
            onChange={update}
            required
          />
        )}

        <input
          name="email"
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={update}
          required
        />

        <input
          name="password"
          type="password"
          placeholder="Password (8+ characters)"
          value={form.password}
          onChange={update}
          minLength={8}
          required
        />

        <button type="submit">
          {mode === "login" ? "Login" : "Register"}
        </button>
      </form>

      <div className="actions">
        <button onClick={() => setMode(mode === "login" ? "register" : "login")}>
          Switch to {mode === "login" ? "Register" : "Login"}
        </button>
        <button onClick={profile}>Get Profile</button>
        <button onClick={logout}>Logout</button>
      </div>

      <pre>{message}</pre>
    </main>
  );
}
