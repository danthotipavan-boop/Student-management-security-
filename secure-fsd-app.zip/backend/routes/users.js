const express = require("express");
const User = require("../models/User");
const { authenticate, adminOnly } = require("../middleware/auth");

const router = express.Router();

router.get("/me", authenticate, async (req, res) => {
  const user = await User.findById(req.user.userId).select("-password");

  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  res.json(user);
});

router.get("/admin-data", authenticate, adminOnly, async (req, res) => {
  const count = await User.countDocuments();
  res.json({ message: "Protected admin data", totalUsers: count });
});

module.exports = router;
